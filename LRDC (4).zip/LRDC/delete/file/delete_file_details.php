<?php
require("../../database/db.php");

$filename=$_GET['filename'];

$sql="delete from file where file_name=?";
if ($stmt = mysqli_prepare($con, $sql)) {

    mysqli_stmt_bind_param($stmt, "s",$filename);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}
?>

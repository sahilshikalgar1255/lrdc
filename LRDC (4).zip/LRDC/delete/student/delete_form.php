<?php
 session_start();
 require("../../import/session.php");

require("db.php");
$sql="select  * from class";
$result=mysqli_query($con,$sql) or die("Failed to execute query");


?>
<html>

<head>
    <title>LRDC</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.css">
</head>

<body>
<h2 class="text-danger text-center" style="margin-top:5%;">DELETE STUDENT</h2>

<div class="container bg-light" style="margin-bottom:10%;">

  <form name="myform">
    <center>
    <label>SELECT CLASS</label><br>
    <select onchange="showStudents()" name="class1" id="class1">
      <option>select class</option>
      <?php
      	while($row = mysqli_fetch_row($result))
      	{
			?><option value="<?php echo $row[0]; ?>"> <?php echo $row[1]; ?></option>
			<?php
      	}
    ?>

    </select>
</center>
<br>
<br>

    <div style="margin-left:25%;overflow-y: scroll;height: 500px;" id="students" >
   
    </div>
  </form>

</div>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script type="text/javascript">
  
  
</script>
</body>
</html>



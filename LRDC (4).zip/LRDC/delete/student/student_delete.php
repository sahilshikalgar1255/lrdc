<?php
 session_start();
 require("../../import/session.php");
require("db.php");
$sql="select  * from class";
$result=mysqli_query($con,$sql) or die("Failed to execute query");

?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/bootstrap.css">
</head>

<body>
<h2 class="text-danger text-center" style="margin-top:5%;">DELETE STUDENT</h2>

<div class="container bg-light" style="width:50%; padding:2%; margin-bottom:10%;">

    <form method="post" action="student_deletion.php">
        <label>USER NAME</label><br>
        <input type="text" class="form-control" placeholder="Enter User Name" required name="username"><br>
        <br><br>
        <div style="margin-left:30%;">
            <input type="submit" style=" margin: 10px 10px 20px 30px;" class="btn btn-success" name="register" value="Register">
            <input type="reset" style=" margin: 10px 10px 20px 30px;" class="btn btn-success" value="Reset  ">
        </div>
    </form>

</div>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
</body>


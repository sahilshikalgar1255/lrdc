<?php
 session_start();
 require("../../import/session.php");
require("../../database/db.php");
ini_set('error_reporting',E_ALL);
ini_set('display_errors','On');
   

        $sql="delete from student where student_id=?";
        $stmt = mysqli_prepare($con,$sql);

       		 mysqli_stmt_bind_param($stmt,"i",$sid);
       		 $sid = $_POST['sid'];
       		 
     
       		 mysqli_stmt_execute($stmt);
        	 mysqli_stmt_close($stmt);
		
?>

<?php
require("../../database/db.php");
ini_set('error_reporting',E_ALL);
ini_set('display_errors','On');
   

        $sql="delete from faculty where faculty_id=?";
        $stmt = mysqli_prepare($con,$sql);

       		 mysqli_stmt_bind_param($stmt,"i",$fid);
       		 $fid = $_POST['fid'];
       		 
     
       		 mysqli_stmt_execute($stmt);
        	 mysqli_stmt_close($stmt);
		
?>

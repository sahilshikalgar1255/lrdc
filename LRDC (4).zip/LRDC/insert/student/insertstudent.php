<?php
session_start();
require("../../database/db.php");
require("../../import/session.php");
if(isset($_POST["submit"])) //check if submit button is pressed or not.
{
 	if($_FILES['file']['name']) //check if file is selected or not.
	{
		$filename=explode(".",$_FILES['file']['name']); //get text after . from file name.
		if($filename[1]=='csv')	//check file exception is csv or not.
		{
			$handle=fopen($_FILES['file']['tmp_name'],"r"); //open csv file in read mode.
			while($data=fgetcsv($handle)) //get data from csv file.
			{
				$item1=mysqli_real_escape_string($con,$data[0]);
				$item2=mysqli_real_escape_string($con,$data[1]);
				mkdir("../../users/student/".$item2,0777);
				$item3=mysqli_real_escape_string($con,$data[2]);
				$item4=mysqli_real_escape_string($con,$data[3]);
				$item5=mysqli_real_escape_string($con,$data[4]);
				$item6=mysqli_real_escape_string($con,$data[5]);
				$item7=mysqli_real_escape_string($con,$data[6]);

				//The mysqli_real_escape_string() function escapes special characters in a string for use in an SQL statement.
				$sql="insert into student(student_id,username,password,first_name,last_name,is_active,class_id) values('$item1','$item2','$item3','$item4','$item5','$item6','$item7')"; //insert above data into database table.
				$x=mysqli_query($con,$sql); //execute query.
			}
			fclose($handle);
			echo "<script>  alert('Student Data Inserted Successfully'); window.location.href='javascript:history.go(-1)'; </script>";
		//header('location:'.$_SERVER['HTTP_REFERER']);	
		}
	}
}
?>

<html>
<body>
<form method=post action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype='multipart/form-data'>

<div align='center'>
	<h2>Insert Student Data</h2>
<p>Upload CSV:<input type=file name=file /></p>
<p><input type=submit name=submit  value=import /></p>
</div>
</form>
</body>
</html>

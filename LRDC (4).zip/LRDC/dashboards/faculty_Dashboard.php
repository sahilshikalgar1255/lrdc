<?php
	include("../import/header.php");
    require("../import/session.php");
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.4/css/jquery.dataTables.css">

    <script>
        var viewmode = getCookie("view-mode");
        if(viewmode == "desktop"){
        viewport.setAttribute('content','width=1024');
        }else if(viewmode == "mobile"){
		viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
	   }
    </script>

    <style>
	.div1{
		display:none;
	}

    </style>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../import/css/bootstrap.css">
</head>
<body>

<div class="w3-sidebar w3-bar-block " style="width:20%;height:100%;background:linear-gradient(rgba(70,140,70,0.7),rgba(17,76,60,1.0));color:white;">
    <h3 class="w3-bar-item">Welcome <?php  $username=$_SESSION['username']; echo $username;?></h3>
    <a onclick="showfiles()"  class="w3-bar-item w3-button">View Files </a>
    <a onclick="uploadfiles()" class="w3-bar-item w3-button">Upload Files</a>
    <a onclick="showstudentfiles()" class="w3-bar-item w3-button">Verify Student Files</a>
    <a onclick="updatefacultyprofile()" class="w3-bar-item w3-button">Update Profile</a>

</div>

<div id=vf1  style="margin-left:25%; margin-top:5%;">
</div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>

<script>

    function showfiles()
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/subject/show_subject.php",true);
        obj.send();
        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function selectsubject(cls){

         var obj = new XMLHttpRequest();
        obj.open("POST","../display/subject/selectsubject.php",true);
        obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        obj.send("cls="+cls);

        obj.onreadystatechange = function()
        {

           if(this.readyState == 4 && this.status == 200)
           {
            document.getElementById("sub").innerHTML = obj.responseText;
           }
        }
    }

    function showsub(subjectname)
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/file/show_file.php?subjectname="+subjectname,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("x").innerHTML = obj.responseText;
            }
        }
    }


    function  uploadfiles() {
        var obj = new XMLHttpRequest();
        obj.open("GET","../upload/upload.php",true);
        obj.send();

        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function getsubject(classname)
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/subject/getsubject.php?classname="+classname,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("subject").innerHTML = obj.responseText;
            }
        }
    }

    function updatefacultyprofile()
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../update/faculty/updatefacultyprofile.php",true);
        obj.send();
        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function updatefaculty()
    {

        if(confirm("Are you Sure? Do You Want to Update your Profile?"))
        {
            var fname = document.getElementById("first_name").value;
            var lname = document.getElementById("last_name").value;
            var username = document.getElementById("username").value;
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            var contact = document.getElementById("phno").value;
            var active = document.getElementById("is_active").value;
            var obj = new XMLHttpRequest();
            obj.open("POST","../update/faculty/updatefaculty.php",true);
            obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            obj.send("fname="+fname+"&lname="+lname+"&email="+email+"&password="+password+"&contact="+contact+"&active="+active);

            obj.onreadystatechange = function()
            {

                if(this.readyState == 4 && this.status == 200)
                {
                    alert("Data Updated Successfully");
                }
            }
       }
    }

     function showstudentfiles(){

        var obj = new XMLHttpRequest();
        obj.open("GET","../display/student/showstudentfiles.php",true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function  verifyfiles(filename) {

        var obj = new XMLHttpRequest();
        obj.open("GET","../upload/upload_file_details.php?filename="+filename,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                alert("File is verified");
                showstudentfiles();
            }
        }
    }

    function  deletefiles(filename) {

        var obj = new XMLHttpRequest();
        obj.open("GET","../delete/file/delete_file_details.php?filename="+filename,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                alert("File is deleted");
                showstudentfiles();
            }
        }
    }
</script>
<script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.2.min.js"></script>
<script src = "http://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js" defer ></script>
<script>
    $(document).ready(function(){
        $(document).ready(function() {
            $('#files').DataTable( {
                "ajax": "../display/student/showstudentfiles.php"
            });
        });
    });  
</script>   
</body>
</html>
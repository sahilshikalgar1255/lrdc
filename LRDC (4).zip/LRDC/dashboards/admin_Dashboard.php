<?php

include("../import/header.php");
require("../import/session.php");


?>

<!DOCTYPE html>
<html>
<head>
    
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script>
	var viewmode = getCookie("view-mode");
	if(viewmode == "desktop"){
		viewport.setAttribute('content','width=1024');
	}else if(viewmode == "mobile"){
		viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
	}
  </script>
    <style>
        .div1{
            display:none;
        }
        h2{
             letter-spacing: 4px;
             word-spacing: 5px;
        }
       
    </style>
    <meta charset="utf-8">

    <link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>

<div class="w3-sidebar w3-bar-block " style="width:20%;height:100%;background:linear-gradient(rgba(70,140,70,0.7),rgba(17,76,60,1.0));color:white;">
    <h3 class="w3-bar-item">Welcome <?php  $username=$_SESSION['username']; echo $username;?>,</h3>
    <a href="admin_Dashboard.php" class="w3-bar-item w3-button">Home</a>
    <a onclick="showfiles()"  class="w3-bar-item w3-button">View Files </a>
    <a onclick="uploadfiles()"F class="w3-bar-item w3-button">Upload Files</a>
    <a onclick="showstudentfiles()" class="w3-bar-item w3-button">Verify Student Files</a>
    <a href="#" class="w3-bar-item w3-button">Settings</a>
</div>


<div  style="margin-left:20%;">

    <nav class="navbar navbar-expand-md" style="background:linear-gradient(rgba(70,140,70,0.7),rgba(17,76,60,1.0));color:white;">
        <ul class="navbar-nav">
            <li class="navbar-brand"><a style="cursor:pointer;" onclick="registerStudent()">Add Student</a></li>
              <li class="navbar-brand"><a style="cursor:pointer;" onclick="deleteStudent()">Delete Student</a></li>
             <li class="navbar-brand"><a style="cursor:pointer;" onclick="registerFaculty()">Add Faculty</a></li>
               <li class="navbar-brand"><a style="cursor:pointer;" onclick="deleteFaculty()">Delete Faculty</a></li>
        </ul>
    </nav>
</div>

<div id="output" style="margin-left:25%;overflow-y: scroll;height: 550px;">
</div>
<br>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script type="text/javascript">
	 function registerStudent() {
      
       var obj = new XMLHttpRequest();
       obj.open("GET","../insert/student/insertstudent.php",true);
       obj.send();

       obj.onreadystatechange = function()
       {
           if(this.readyState == 4 && this.status == 200)
           {
               document.getElementById("output").innerHTML = obj.responseText;
           }
       }
    }

    function  registerFaculty() {
    
       var obj = new XMLHttpRequest();
       obj.open("GET","../insert/faculty/insertfaculty.php",true);
       obj.send();

       obj.onreadystatechange = function()
       {
           if(this.readyState == 4 && this.status == 200)
           {
               document.getElementById("output").innerHTML = obj.responseText;
           }
       }
    }

    function deleteStudent(){

        var obj = new XMLHttpRequest();
       obj.open("POST","../delete/student/delete_student_form.php",true);
       
       obj.send();

       obj.onreadystatechange = function()
       {
           if(this.readyState == 4 && this.status == 200)
           {
             document.getElementById("output").innerHTML = obj.responseText;
           }
       }
    }

    function showStudents() {

        var class1 = document.getElementById("class1").value;
        var obj = new XMLHttpRequest();
        obj.open("POST","../display/student/show_students.php",true);
        obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        obj.send("class1="+class1);

        obj.onreadystatechange = function()
        {

           if(this.readyState == 4 && this.status == 200)
           {
            document.getElementById("students").innerHTML = obj.responseText;
           }
        }
    }

    function deleteStudentRecord(sid){

       var obj = new XMLHttpRequest();
       obj.open("POST","../delete/student/deleteStudentRecord.php",true);
       obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
       obj.send("sid="+sid);

       obj.onreadystatechange = function()
       {
           if(this.readyState == 4 && this.status == 200)
           {
             alert("deleted");
             showStudents();
           }
       }
    }

    function deleteFaculty(){

        var obj = new XMLHttpRequest();
        obj.open("POST","../delete/faculty/delete_faculty_form.php",true);
       
        obj.send();

        obj.onreadystatechange = function()
        {
           if(this.readyState == 4 && this.status == 200)
           {
             document.getElementById("output").innerHTML = obj.responseText;
           }
       }
    }

    function deleteFacultyRecord(fid){

       var obj = new XMLHttpRequest();
       obj.open("POST","../delete/faculty/deleteFacultyRecord.php",true);
       obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
       obj.send("fid="+fid);

       obj.onreadystatechange = function()
       {
           if(this.readyState == 4 && this.status == 200)
           {
             alert("deleted");
             showFaculty();
           }
       }
    }

    function showFaculty() {

        var role = document.getElementById("role").value;
        var obj = new XMLHttpRequest();
        obj.open("POST","../display/faculty/show_faculty.php",true);
        obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        obj.send("role="+role);

        obj.onreadystatechange = function()
        {

           if(this.readyState == 4 && this.status == 200)
           {
            document.getElementById("students").innerHTML = obj.responseText;
           }

        }
    }

     function showfiles()
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/subject/show_subject.php",true);
        obj.send();
        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("output").innerHTML = obj.responseText;
            }
        }
    }

    function selectsubject(cls){

        var cls =document.getElementById('year').value;
         var obj = new XMLHttpRequest();
        obj.open("POST","../display/subject/selectsubject.php",true);
        obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        obj.send("cls="+cls);

        obj.onreadystatechange = function()
        {

           if(this.readyState == 4 && this.status == 200)
           {
            document.getElementById("sub").innerHTML = obj.responseText;
           }
        }
    }

    function showsub(subjectname)
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/file/show_file.php?subjectname="+subjectname,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("x").innerHTML = obj.responseText;
            }
        }
    }
 
    function  verifyfiles(filename) {

        var obj = new XMLHttpRequest();
        obj.open("GET","upload_file_details.php?filename="+filename,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                alert("File is verified");
                show();
            }
        }
    }

    function  uploadfiles() {
        var obj = new XMLHttpRequest();
        obj.open("GET","../upload/upload.php",true);
        obj.send();

        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("output").innerHTML = obj.responseText;
            }
        }
    }

    function getsubject(classname)
    {

        var obj = new XMLHttpRequest();
        obj.open("GET","../display/subject/getsubject.php?classname="+classname,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("subject").innerHTML = obj.responseText;
            }
        }
    }

     function showstudentfiles(){

        var obj = new XMLHttpRequest();
        obj.open("GET","../display/student/showstudentfiles.php",true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("output").innerHTML = obj.responseText;
            }
        }
    }

     function  verifyfiles(filename) {

        var obj = new XMLHttpRequest();
        obj.open("GET","../upload/upload_file_details.php?filename="+filename,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                alert("File is verified");
                showstudentfiles();
            }
        }
    }

    function  deletefiles(filename) {

        var obj = new XMLHttpRequest();
        obj.open("GET","../delete/file/delete_file_details.php?filename="+filename,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                alert("File is deleted");
                showstudentfiles();
            }
        }
    }




	
</script>


</body>
</html>

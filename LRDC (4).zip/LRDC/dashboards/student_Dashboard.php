<?php
    include("../import/header.php");
    require("../import/session.php");	
?>

    <!DOCTYPE html>
    <html>
<head>
   
   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

      <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables.css">
      <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables_themeroller.css">


        <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.1.min.js"></script>
        <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/jquery.dataTables.min.js"></script>

     <script>
	var viewmode = getCookie("view-mode");
	if(viewmode == "desktop"){
		viewport.setAttribute('content','width=1024');
	}else if(viewmode == "mobile"){
		viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
	}
  </script>
    <style>
        .div1{
            display:none;
        }

    </style>
    <meta charset="utf-8">

   <!-- <link rel="stylesheet" href="css/bootstrap.css">-->

</head>
<body>

<div class="w3-sidebar w3-bar-block " style="width:20%;height:100%;background:linear-gradient(rgba(70,140,70,0.7),rgba(17,76,60,1.0));color:white;">
    <h3 class="w3-bar-item">Welcome <?php  $username=$_SESSION['username']; echo $username;?></h3>
    <a onclick="showfiles()"  class="w3-bar-item w3-button">View Files </a>
    <a onclick="uploadfiles()" class="w3-bar-item w3-button">Upload Files</a>
    <a onclick="updatestudentprofile()" class="w3-bar-item w3-button">Update Profile</a>

</div>
    
<div id=vf1  style="margin-left:25%; margin-top:5%;">
</div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>

<script>
    function showfiles()
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/subject/show_subject_student.php",true);
        obj.send();
        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function showsub(subjectname)
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../display/file/show_file.php?subjectname="+subjectname,true);
        obj.send();

        obj.onreadystatechange = function()
        {

            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("x").innerHTML = obj.responseText;
            }
        }
    }

    function updatestudentprofile()
    {
        var obj = new XMLHttpRequest();
        obj.open("GET","../update/student/updatestudentprofile.php?",true);
        obj.send();
        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function updatestudent()
    {
        if(confirm("Are you Sure? Do You Want to Update your Profile?"))
        {
            var fname = document.getElementById("first_name").value;
            var lname = document.getElementById("last_name").value;
            var username = document.getElementById("username").value;
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            var contact = document.getElementById("phno").value;
            var class1 = document.getElementById("class_id").value;
            var active = document.getElementById("is_active").value;
            
            var obj = new XMLHttpRequest();
            obj.open("POST","../update/student/updatestudent.php",true);
            obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
            obj.send("fname="+fname+"&lname="+lname+"&email="+email+"&password="+password+"&contact="+contact+"&class1="+class1+"&active="+active);

            obj.onreadystatechange = function()
            {

                if(this.readyState == 4 && this.status == 200)
                {
                    alert("Data Updated Successfully");
                }
            }
       }
    }


    function  uploadfiles() {
        var obj = new XMLHttpRequest();
        obj.open("GET","../upload/studentuploadfile.php",true);
        obj.send();

        obj.onreadystatechange = function()
        {
            if(this.readyState == 4 && this.status == 200)
            {
                document.getElementById("vf1").innerHTML = obj.responseText;
            }
        }
    }

    function showclass() {

        var subject_name = document.getElementById("subject_name").value;
        var obj = new XMLHttpRequest();
        obj.open("POST","../display/class/show_class.php",true);
        obj.setRequestHeader("Content-type","application/x-www-form-urlencoded");
        obj.send("subject_name="+subject_name);

        obj.onreadystatechange = function()
        {

           if(this.readyState == 4 && this.status == 200)
           {
            document.getElementById("class").innerHTML = obj.responseText;
           }
        }
    }
    
    $(document).ready(function () {
        $('#myfiles').DataTable();
    });
</script>
</body>
</html>

-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 24, 2019 at 01:19 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lrdc1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `email`) VALUES
(1, 'hitesh1', 'hitesh1', 'hitesh.pawar1010@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

DROP TABLE IF EXISTS `class`;
CREATE TABLE IF NOT EXISTS `class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(50) NOT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `class_name`) VALUES
(1, 'FYMCA'),
(2, 'SYMCA'),
(3, 'TYMCA');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phno` varchar(10) DEFAULT NULL,
  `is_active` int(11) DEFAULT '0',
  `role` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`faculty_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `username`, `password`, `email`, `first_name`, `last_name`, `phno`, `is_active`, `role`) VALUES
(1, 'suchita1', 'suchita1', 'suchitaborkar@gmail.com', 'Suchita', 'Borkar', '1111111', 1, 'Teaching Staff'),
(5, 'rajkamal5', 'rajkaml5', NULL, 'Rajkamal', 'Sangole', NULL, 1, NULL),
(4, 'anand4', 'anand4', NULL, 'Anand', 'Jain', NULL, 1, NULL),
(3, 'prashant3', 'prashant3', NULL, 'Prashant', 'Kulkarni', NULL, 1, NULL),
(2, 'sopan2', 'sopan2', NULL, 'Sopan', 'Aghav', NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
CREATE TABLE IF NOT EXISTS `file` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  `description` varchar(400) NOT NULL,
  `size` varchar(50) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `academic_year` int(11) NOT NULL,
  `upload_date` date NOT NULL,
  `is_active` int(11) DEFAULT '0',
  `file_name` varchar(100) NOT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file`
--

INSERT INTO `file` (`file_id`, `file_path`, `file_type`, `description`, `size`, `student_id`, `faculty_id`, `guest_id`, `subject_id`, `class_id`, `academic_year`, `upload_date`, `is_active`, `file_name`) VALUES
(27, 'C:wamp64wwwLRDC/amey1/faculty.csv', 'pdf', 'PNC File', '176', 1, NULL, NULL, 3, 2, 2019, '2019-10-24', 1, 'faculty.csv'),
(28, 'C:wamp64wwwLRDC/amey1/student.csv', 'pdf', 'BPD File', '163', 1, NULL, NULL, 1, 1, 2019, '2019-10-24', 1, 'student.csv');

-- --------------------------------------------------------

--
-- Table structure for table `file1`
--

DROP TABLE IF EXISTS `file1`;
CREATE TABLE IF NOT EXISTS `file1` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100) NOT NULL,
  `description` varchar(400) NOT NULL,
  `size` varchar(50) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `guest_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  `academic_year` int(11) NOT NULL,
  `upload_date` date NOT NULL,
  `is_active` int(11) DEFAULT '0',
  `file_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

DROP TABLE IF EXISTS `guest`;
CREATE TABLE IF NOT EXISTS `guest` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phno` varchar(10) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phno` varchar(10) DEFAULT NULL,
  `is_active` int(11) DEFAULT '0',
  `class_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `username`, `password`, `email`, `first_name`, `last_name`, `phno`, `is_active`, `class_id`) VALUES
(1, 'amey1', 'amey1', 'amey@gmail.com', 'amey', 'taksale', '9876543210', 1, 2),
(6, 'dhiraj6', 'dhiraj6', NULL, 'Dhiraj', 'Saitwal', NULL, 1, NULL),
(5, 'satu5', 'satu5', NULL, 'Satu', 'Patekar', NULL, 1, NULL),
(4, 'jayraj4', 'jayraj4', NULL, 'Jayraj', 'Patil', NULL, 1, NULL),
(3, 'kunal3', 'kunal3', NULL, 'Kunal', 'Pawar', NULL, 1, NULL),
(2, 'rehan2', 'rehan2', NULL, 'Rehan', 'Sayyad', NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
CREATE TABLE IF NOT EXISTS `subject` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(50) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `class_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`subject_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`, `faculty_id`, `class_id`) VALUES
(3, 'PNC', 1, 2),
(2, 'C With DS', 3, 1),
(1, 'BPD', 2, 1),
(4, 'OOAD', 4, 2),
(5, 'Python', 5, 3),
(6, 'Advance Database', 6, 3);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

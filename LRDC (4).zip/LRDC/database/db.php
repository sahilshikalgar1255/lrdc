<?php

$con=mysqli_connect("localhost","root","","lrdc1") or die("Failed to connect");


?>

 <head>
    
    <link rel="stylesheet" href="css/bootstrap.css">
     <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
 </head>


<?php
include("../import/header.php");
require("../database/db.php");
require("../import/session.php");

$folder=$_COOKIE['fold'];
$name = $_FILES['myfile'];
$filename = $_FILES['myfile']['name'];
setcookie("filename",$filename);
$username=$_SESSION['username'];
$user = $_SESSION['fid'];
$type = $_POST['type'];
$desc = $_POST['desc'];
$subject = $_POST['subject_name'];
//$year = $_POST['year'];
$dname = $_POST['dept_name'];
$file_loc=$_FILES['myfile']['tmp_name'];
$size = $_FILES['myfile']['size'];
$name1=$_FILES['myfile']['name'];
$folder1=$_COOKIE['fold'];
$folder="../users/".$user."/".$folder1."/".$filename;
//$file = $_FILES['myfile'];
$date = date('Y-m-d');
$class=$_POST['class'];



	
	$q = "select subject_id from subject where subject_name='$subject'";
	$res = mysqli_query($con,$q) or die("Failed to execute query");
	
	if($row = mysqli_fetch_row($res))
	{
	$sid = $row[0];
	}
	else
		echo"nothing in row";

	$q1 = "select student_id from student where username='$username'";
	$res1 = mysqli_query($con,$q1) or die("Failed to execute query");
	
	if($row = mysqli_fetch_row($res1))
	{
	$stid = $row[0];
	}



if(move_uploaded_file($file_loc, $folder))
{
 
    $q = "insert into file(file_path,file_type,description,size,student_id,subject_id,academic_year,upload_date,file_name,class_id) values('$folder','$type','$desc','$size',$stid,$sid,2019,'$date','$filename','$class')";

	 mysqli_query($con,$q) or die("Failed to execute insert query");
	 echo "<script>  alert('Wait for file verification'); window.location.href='javascript:history.go(-1)'; </script>";
	
}
?>

  

<?php
session_start();
require("../database/db.php");
require("../import/session.php");
$username = $_SESSION['username'];
$cwd=getcwd();
$folder=$username;
setcookie("fold",$folder);


?>

<head>

    <link rel="stylesheet" href="../import/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script>
	var viewmode = getCookie("view-mode");
	if(viewmode == "desktop"){
		viewport.setAttribute('content','width=1024');
	}else if(viewmode == "mobile"){
		viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
	}
  </script>
</head>
<body>

<h1 style="margin-top:2%;">Upload Your File</h1>
<br>

  
    <div class="container bg-light" style="padding: 5px;">
    	 <form method="post" enctype="multipart/form-data" action="../upload/receive.php" class="form-group" >
        <div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">           
				<label>TYPE</label>
			</div>

			<div class="col-md-6">
	        	<select name="type">
		            <option value="pdf" name="pdf">PDF</option>
		            <option value="audio" name="audio">audio</option>
		            <option value="video" name="video">video</option>
               	</select>
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">          	
           		 <label>DESCRIPTION</label></td>
			</div>

			<div class="col-md-6">
                    <input type="text" name="desc" class="form-control">
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">  
            		<label>SELECT CLASS</label>
			</div>

			<div class="col-md-6">    
                	<select name="class_name" onchange="getsubject(this.value)">
                       		<option>Select Class</option>
                        	<option value="FYMCA">FYMCA</option>
                        	<option value="SYMCA">SYMCA</option>
                        	<option value="TYMCA">TYMCA</option>
                    </select>
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">          	
           		 <label>SELECT SUBJECT</label>
			</div>

			<div class="col-md-6" name="subject" id="subject">       
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">  
         		 <label>ACADEMIC YEAR</label>
			</div>

			<div class="col-md-6">  
           	     <input type="number" min="2005" max="2020" step="1" value="2019" name="year"/>
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">  
            		<label>DEPARTMENT</label>
			</div>

			<div class="col-md-6"> 
	        	<select name="dept_name">
		        <option value="mca" name="mca">MCA</option>
                </select>
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">  
           		<label>SELECT FILE</label>
			</div>

			<div class="col-md-6">  
            		<input  type="file" name="myfile"/>
			</div>
		</div>

		<div class="row" style="margin-bottom:2%;">
			<div class="col-md-6" style="text-align:center;">  
				<input type="submit" class="btn btn-primary"  name="upload" value="UPLOAD"/>
			</div>

			<div class="col-md-6" style="text-align:left;">  
				<input type="reset" class="btn btn-primary" value="RESET"/>
			</div>
		</div>
    </form>
      
     </div>



</body>


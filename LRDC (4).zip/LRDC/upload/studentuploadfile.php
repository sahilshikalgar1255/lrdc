<?php
session_start();
$username = $_SESSION['username'];
$cwd=getcwd();
$folder=$username;
setcookie("fold",$folder);

require("../database/db.php");
require("../import/session.php");
?>

<head>
 
    <link rel="stylesheet" href="css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script>
	var viewmode = getCookie("view-mode");
	if(viewmode == "desktop"){
		viewport.setAttribute('content','width=1024');
	}else if(viewmode == "mobile"){
		viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
	}
  </script>
</head>
<body>

<h1 style="margin-top:2%;">Upload Your File </h1>
<br>

   <form method="post" enctype="multipart/form-data" action="../upload/studentreceivefile.php" class="form-group" >
    <div class="container bg-light">
        <div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">           
			<label>TYPE</label>
		</div>
		<div class="col-md-6">
	        	<select name="type">
		            <option value="pdf" name="pdf">PDF</option>
		            <option value="audio" name="audio">audio</option>
		            <option value="video" name="video">video</option>
               		 </select>
		</div>
	</div>

	<div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">          	
           		 <label>DESCRIPTION</label></td>
		</div>
		<div class="col-md-6">
                    <input type="text" name="desc" class="form-control">
		</div>
	</div>

	<div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">          	
           		 <label>SELECT SUBJECT</label>
		</div>
		<div class="col-md-6">       
                	<select name="subject_name" id="subject_name" onchange="showclass()">
                       		<option>Select Subject</option>
	
					<?php
							$sql = "select subject_name from subject";
							$stmt = mysqli_prepare($con,$sql);
          					mysqli_stmt_execute($stmt);
          					mysqli_stmt_bind_result($stmt, $sub_name);

          					while (mysqli_stmt_fetch($stmt)) {
        					?><option value="<?php echo $sub_name; ?>"><?php echo $sub_name; ?></option><?php
    						}
					?>
	                </select>
		</div>
	</div>

	<div  id="class" name="class" class="row" style="margin-bottom:2%;"> <!-- To Display Class-->
	</div>

	<div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">  
         		 <label>ACADEMIC YEAR</label>
		</div>
		<div class="col-md-6">  
           	     <input type="number" min="2005" max="2020" step="1" value="2019" name="year"/>
		</div>
	</div>

	<div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">  
            		<label>DEPARTMENT</label>
		</div>
		<div class="col-md-6"> 
	        	<select name="dept_name">
		        <option value="mca" name="mca">MCA</option>
                </select>
		</div>
	</div>

	<div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">  
           		<label>SELECT FILE</label>
		</div>
		<div class="col-md-6">  
            		<input  type="file" name="myfile"/>
		</div>
	</div>

	<div class="row" style="margin-bottom:2%;">
		<div class="col-md-6" style="text-align:center;">  
			<input type="submit" class="btn btn-primary"  name="upload" value="UPLOAD"/>
		</div>
		<div class="col-md-6" style="text-align:left;">  
			<input type="reset" class="btn btn-primary" value="RESET"/>
		</div>
	</div>
      
     </div>
    </form>


</script>
</body>


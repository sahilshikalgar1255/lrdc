 <head>
   
    <link rel="stylesheet" href="../import/css/bootstrap.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
 </head>

<?php
include("../import/header.php");
require("../database/db.php");
require("../import/session.php");

//$folder=$_COOKIE['fold'];
$name = $_FILES['myfile'];
$filename = $_FILES['myfile']['name'];
setcookie("filename",$filename);
$username=$_SESSION['username'];
$type = $_POST['type'];
$desc = $_POST['desc'];
$subject = $_POST['subject'];
$user = $_SESSION['fid'];
//$year = $_POST['year'];
$dname = $_POST['dept_name'];
$file_loc=$_FILES['myfile']['tmp_name'];
$size = $_FILES['myfile']['size'];
$name1=$_FILES['myfile']['name'];
$folder1=$_COOKIE['fold'];
$folder="../users/".$user."/".$folder1."/".$filename;
//$file = $_FILES['myfile'];
$date = date('Y-m-d');


	$q = "select subject_id,faculty_id from subject where subject_name='$subject'";
	$res = mysqli_query($con,$q) or die("Failed to execute query");
	
	if($row = mysqli_fetch_row($res))
	{
	$sid = $row[0];
	$tid = $row[1];
	}
	else
	{
		echo "<script> window.location.href='javascript:history.go(-1)'; </script>";
	}


if(move_uploaded_file($file_loc, $folder))
{
 
    $q = "insert into file(file_path,file_type,description,size,faculty_id,subject_id,academic_year,upload_date,is_active,file_name) values('$folder','$type','$desc','$size',$tid,$sid,2019,'$date',1,'$filename')";

	 mysqli_query($con,$q) or die("Failed to execute insert query");
	 	echo "<script>  alert('File Uploaded successfully'); window.location.href='javascript:history.go(-1)'; </script>";
	
}
?>
 

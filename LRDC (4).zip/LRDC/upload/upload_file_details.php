<?php
require("../database/db.php");
require("../import/session.php");

$filename=$_GET['filename'];

$sql="update file set is_active=? where file_name=?";
if ($stmt = mysqli_prepare($con, $sql)) {

    mysqli_stmt_bind_param($stmt, "is", $is_active,$filename);
    $is_active='1';
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}
?>

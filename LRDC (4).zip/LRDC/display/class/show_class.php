<?php
 session_start();
 require("../../import/session.php");
require("../../database/db.php");

ini_set('error_reporting',E_ALL);
ini_set('display_errors','On');
   

        $sql="select class_id from subject where subject_name=?";
       $stmt = mysqli_prepare($con, $sql);

       		 mysqli_stmt_bind_param($stmt,"s",$subject_name);
           $subject_name = $_POST['subject_name'];
        
        	 mysqli_stmt_bind_result($stmt,$class_id);

          // $uname1 = $uname;
     
       		 mysqli_stmt_execute($stmt);
           ?>
           <div class="container" style="display: inline">
                  <div class="col-md-3" style="display: inline; margin-left: 19%;" >
                  Class
                  </div>
                
                  <div class="col-md-3" style="display: inline; margin-left: 24%;">
                  <?php
                    while (mysqli_stmt_fetch($stmt)) 
                    ?><input type=text name="class" class="bg-light" value="<?php echo $class_id;?>" readonly>
                
                  </div>
            </div>
        <?php  
        	 mysqli_stmt_close($stmt);
        ?>
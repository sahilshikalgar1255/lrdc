<?php
   session_start();
 require("../../import/session.php");
  require("../../database/db.php");

  ini_set('error_reporting',E_ALL);
  ini_set('display_errors','On');
   
  $sql="select subject_name from subject where class_id in (select class_id from class where class_name=?)";
  $stmt = mysqli_prepare($con, $sql);

  mysqli_stmt_bind_param($stmt,"s",$class_name);
  $class_name=$_POST['cls'];       
  mysqli_stmt_bind_result($stmt,$subject_name);
  mysqli_stmt_execute($stmt);
?>
  <div class="container" style="display: inline">
              
  <div class="col-md-3" style="display: inline; ">
    <select onchange="showsub(this.value)">
        <option>Select Subject</option>
<?php
        while (mysqli_stmt_fetch($stmt))
        { 
?>
          <option id=<?php echo $subject_name?> > <?php echo "$subject_name" ?> </option>
<?php  }
        mysqli_stmt_close($stmt);
?>
    </select>
  </div> 
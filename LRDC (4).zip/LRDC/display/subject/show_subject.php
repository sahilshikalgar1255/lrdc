<?php
 session_start();
 require("../../import/session.php");
require("../../database/db.php");
?>
<body>
<div class="container">
	<div class="row">
		<div class="col-md-6">
   			 <h2><label>Select Year</label></h2>
		</div>
		<div class="col-md-6">
			<h2><label>Select Subject</label></h2>
		</div>
	</div>
	
	<div class="row">
		<div class="col-md-6">
  			<select id="year" value="year" onchange="selectsubject(this.value)">
     			   <option> Select Year</option>
      			  <option value="FYMCA">FYMCA</option>
      			  <option value="SYMCA">SYMCA</option>
      			  <option value="TYMCA">TYMCA</option>
   			</select>
		</div>
	
		<div class="col-md-6" id="sub" name="sub">
		</div>
	</div>
</div>
<div id="x"  style="margin-top:5%;" class="bg-light">
</div>
</body>

<?php
  session_start();
 require("../../import/session.php");
   require("../../database/db.php");

  ini_set('error_reporting',E_ALL);
  ini_set('display_errors','On');
   

  $sql="select subject_name from subject where class_id in(select class_id from class where class_name=?)";
  $stmt = mysqli_prepare($con, $sql);
  mysqli_stmt_bind_param($stmt,"s",$class_name);
  $class_name = $_GET['classname'];
  mysqli_stmt_bind_result($stmt,$subject_name);
  mysqli_stmt_execute($stmt);
?>
  <div class="col-md-3" style="display: inline; margin-left: -3%;">
      <select name="subject" id="subject">
          <option>Select Subject</option>
<?php
          while (mysqli_stmt_fetch($stmt))
          {
?>
            <option name="subject" id="subject" value="<?php echo $subject_name ?>" ><?php echo $subject_name ?> </option>   
  </div>
<?php  
          }
        	mysqli_stmt_close($stmt);
?>

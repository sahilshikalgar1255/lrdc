<?php
 session_start();
 require("../../import/session.php");
require("../../database/db.php");
?>
<?php

$sql = "select subject_name from subject";
if ($stmt = mysqli_prepare($con, $sql)) { ?>
<h2  style="margin-top:5%"><label>Select Subject</label></h2><br>
<?php
//mysqli_stmt_bind_param($stmt, "s", $className);
//$className = 'FYMCA';	
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt,$subject);
?>


<select  id="sid" onchange="showsub(this.value)">
    <option id="select">Select Subject</option>
    <?php
    while (mysqli_stmt_fetch($stmt)) {
        ?>
        <option value='<?php echo $subject; ?>'><?php echo $subject; ?> </option>
    <?php }
    }
    mysqli_stmt_close($stmt);
    ?>
</select>

<div id=x  style="margin-top:5%;">
</div>

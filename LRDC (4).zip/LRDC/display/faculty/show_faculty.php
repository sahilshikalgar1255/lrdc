<?php
 session_start();
 require("../../import/session.php");
require("../../database/db.php");

ini_set('error_reporting',E_ALL);
ini_set('display_errors','On');
   

        $sql="select faculty_id,first_name,last_name,username from faculty where role= ?";
       $stmt = mysqli_prepare($con, $sql);

       		 mysqli_stmt_bind_param($stmt,"s",$role);
          $role= $_POST['role'];
          // $role = "Teaching Staff";
        
       		
        	 mysqli_stmt_bind_result($stmt, $fid,$fname,$lname,$uname);

          
     
       		 mysqli_stmt_execute($stmt);
           ?>
           <div class="container font-weight-bold">
             <div class="row">
                <div class="col-md-3">
                  First Name
                </div>
                <div class="col-md-3">
                  Last Name
                </div>
                <div class="col-md-3">
                  User Name
                
              </div>
              <div class="col-md-3">
                Action
                
              </div>

            </div>
          </div>
              <br>
              <div class="container">
            <?php
             while (mysqli_stmt_fetch($stmt)) {
              ?>
              <div class="row" style="margin-top:5px;">
                <div class="col-md-3">
                  <?php
                      echo $fname;
                      ?>
                </div>
                <div class="col-md-3">
                  <?php
                     echo $lname;
                      ?>
                </div>
                <div class="col-md-3">
                  <?php
                      echo $uname;
                      ?>
                </div>
                <div class="col-md-3">
                    <input type="button" class="btn btn-danger" value="Delete" onclick="deleteFacultyRecord(<?php echo$fid; ?>)"> 
                   
                </div>
                </div>
                
          <?php
            }
            ?>
              
    
          
        </div>
        <?php
          
        	 mysqli_stmt_close($stmt);
		
?>
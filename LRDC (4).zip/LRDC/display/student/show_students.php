<?php
 session_start();
 require("../../import/session.php");
require("../../database/db.php");

ini_set('error_reporting',E_ALL);
ini_set('display_errors','On');
   

        $sql="select student_id,first_name,last_name,username from student where student.class_id = ?";
       $stmt = mysqli_prepare($con, $sql);

       		 mysqli_stmt_bind_param($stmt,"i",$cid);
           $cid = $_POST['class1'];
        
       		
        	 mysqli_stmt_bind_result($stmt, $sid,$fname,$lname,$uname);

           $uname1 = $uname;
     
       		 mysqli_stmt_execute($stmt);
           ?>
           <div class="container font-weight-bold">
             <div class="row">
                <div class="col-md-3">
                  First Name
                </div>
                <div class="col-md-3">
                  Last Name
                </div>
                <div class="col-md-3">
                  User Name
                
              </div>
              <div class="col-md-3">
                Action
                
              </div>

            </div>
          </div>
              <br>
              <div class="container">
            <?php
             while (mysqli_stmt_fetch($stmt)) {
              ?>
              <div class="row" style="margin-top:5px;">
                <div class="col-md-3">
                  <?php
                      echo $fname;
                      ?>
                </div>
                <div class="col-md-3">
                  <?php
                     echo $lname;
                      ?>
                </div>
                <div class="col-md-3">
                  <?php
                      echo $uname;
                      ?>
                </div>
                <div class="col-md-3">
                    <input type="button" class="btn btn-danger" value="Delete" onclick="deleteStudentRecord(<?php echo$sid; ?>)">
                </div>
                </div>
                
          <?php
            }
            ?>
              
    
          
        </div>
        <?php
          
        	 mysqli_stmt_close($stmt);
		
?>
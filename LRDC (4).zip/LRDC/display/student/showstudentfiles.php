<?php
session_start();
require("../../import/session.php");
require("../../database/db.php");
/*
    $sql ="select faculty_id from faculty where username=?";
    $stmt = mysqli_prepare($con,$sql);
    $username=$_SESSION['username'];
    mysqli_stmt_bind_param($stmt,"s",$username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $faculty_id);
    mysqli_stmt_fetch($stmt);
    mysqli_stmt_close($stmt);

    $sql1="select subject_id from subject where faculty_id=?";
    $stmt1 = mysqli_prepare($con,$sql1);
    $fid=$faculty_id;
    mysqli_stmt_bind_param($stmt1,"i",$faculty_id);
    mysqli_stmt_execute($stmt1);
    mysqli_stmt_bind_result($stmt1, $subject_id);
    mysqli_stmt_fetch($stmt1);
    mysqli_stmt_close($stmt1);  */  
?>

<head>
    <style>
        .anchor:hover
        {
            background-color: yellow;
        }
    </style>
</head>

<?php
    
    //$sql="select file_name,student_id from file where is_active=? and subject_id=? and faculty_id is NULL";
    $sql1="select file_name,student_id from file where is_active=? and faculty_id is NULL and subject_id in(select subject_id from subject where faculty_id in(select faculty_id from faculty where username=?))";

    if ($stmt = mysqli_prepare($con, $sql1))
    {
?>
        <h2 style="margin-top: 5%;"><label>Files List</label></h2><br>
<?php
        mysqli_stmt_bind_param($stmt,"is",$is_active,$username);
        $is_active=0;
        $username=$_SESSION['username'];
        //$sid=$subject_id;
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt,$file_name,$student_id);
?>
        <div><table border="3" id="files" class="table table-striped w-auto">
        <thead>
            <tr>
                <th style="text-align: center;">Files</th>
                <th>Uploaded By</th>
                <th style="">Action</th>
            </tr>
        </thead>
        <tbody>
<?php
        while (mysqli_stmt_fetch($stmt))
        {
?>
            <tr><td><a  href="<?php echo $file_name; ?>"><?php echo $file_name; ?></a></td>
<?php
            setcookie("filename",$file_name);
?>

            <td><?php echo "$student_id" ?></td>

            <td><a class=anchor style="cursor: pointer;" onclick="verifyfiles('<?php echo $file_name?>')">Verify</a><br>
            <a class=anchor style="cursor: pointer;" onclick="deletefiles('<?php echo $file_name?>')">Reject</a><br></td>
            </tr>
<?php
        }
        mysqli_stmt_close($stmt);
    }
?>
    </tbody></table></div>
<!--verifyfiles() and deletefiles() is defined on admmin_Dashboard.php-->
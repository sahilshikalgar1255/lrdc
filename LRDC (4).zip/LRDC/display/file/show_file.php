<html>
<head><!--for Data Tables-->
   <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables.css">
      <link rel="stylesheet" type="text/css" href="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/css/jquery.dataTables_themeroller.css">


        <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.7.1.min.js"></script>
        <script type="text/javascript" charset="utf8" src="http://ajax.aspnetcdn.com/ajax/jquery.dataTables/1.9.0/jquery.dataTables.min.js"></script>
</head>

<?php
    session_start();
    require("../../import/session.php");
    require("../../database/db.php");

    $sql1="select file_name,upload_date,student_id,faculty_id from file where is_active=? and subject_id in (select subject_id from subject where subject_name=?) ";
    if ($stmt1 = mysqli_prepare($con, $sql1))
     {
?>
        <h2><label>Files List</label></h2><br>

<?php    
        mysqli_stmt_bind_param($stmt1, "is",$is_active,$subject_name);
        $is_active=1;
        $subject_name=$_GET['subjectname'];
        mysqli_stmt_execute($stmt1);
        mysqli_stmt_bind_result($stmt1, $file_name,$upload_date,$student_id,$faculty_id);
?>
        <div class="container">
            <table border=2 id="myfiles" name="myfiles">
                 <thead>
            <tr>
                <th>File Name</th>
                <th>Uploaded By</th>
                <th>Upload Date</th>
            </tr>
        </thead> 
<?php
            while (mysqli_stmt_fetch($stmt1)) 
            {
?>
	           <div class="row">
	               <div class="col-md-12">
                    <tbody>
                        <h3><tr><td><a class="text-primary" download="<?php echo "$file_name";?>" href="<?php echo "$file_name";?>" /><?php echo "$file_name";?></td></h3>
                                <?php
                                if($student_id != NULL)
                                ?><td><?php echo $student_id; ?>
                                <?php
                                if($faculty_id != NULL) 
                                    ?><?php echo $faculty_id; ?></td>
                                
                                <td><?php echo $upload_date; ?></td>
                             </tr>
                    </tbody>       
                    </div>
	           </div>

<?php
            }
        mysqli_stmt_close($stmt1);
    }
?>
            </table>
        </div>
</html>
<?php
session_start();
require("../../database/db.php");
require("../../import/session.php");
ini_set('error_reporting',E_ALL);
ini_set('display_errors','On');
$username=$_SESSION['username'];


   $sql="update student set first_name=?,last_name=?,password=?,email=?,phno=? where username=?";
        $stmt = mysqli_prepare($con,$sql);

           $password = $_POST['password'];
           $email = $_POST['email'];
           $fname = $_POST['fname'];
           $lname = $_POST['lname'];
           $contact = $_POST['contact'];
        
         mysqli_stmt_bind_param($stmt,"ssssss",$fname,$lname,$password,$email,$contact,$username);
          mysqli_stmt_execute($stmt);
?>

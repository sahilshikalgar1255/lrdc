<?php
	session_start();
	require("../../database/db.php");
	require("../../import/session.php");
	$username=$_SESSION['username'];
	
	$sql = "select * from student where username=?";

	if ($stmt = mysqli_prepare($con, $sql)) 
	{
		mysqli_stmt_bind_param($stmt, "s", $username);
		mysqli_stmt_execute($stmt);
		mysqli_stmt_bind_result($stmt,$student_id,$username,$password,$email,$first_name,$last_name,$phno,$is_active,$class_id);
		 mysqli_stmt_fetch($stmt);
	}
?>

<html>
<head>
	<style type="text/css">
		.no-drop {
			cursor: no-drop;
		}
	</style>

<body>
<div align="center">
	<h2>Personal Information</h2>
	<table>

	<tr><td>Student ID </td><td><input type="text" id="student_id" class="form-control no-drop" name="student_id" value="<?php echo $student_id ;?>" readonly="readonly" /></td></tr>
	
	<tr><td>User Name </td><td><input type="text"  id= "username" class="form-control no-drop" name="username" value="<?php echo $username ;?>" readonly="readonly" /></td></tr>

	<tr><td>Password</td><td><input type="text" id="password" class="form-control" name="password" value="<?php echo $password ;?>" /></td></tr>

	<tr><td>Email ID</td><td><input type="text" id="email" class="form-control" name="email" value="<?php echo $email ;?>"/></td></tr>

	<tr><td>First name</td><td><input type="text" id="first_name" class="form-control" name="first_name" value="<?php echo $first_name ;?>"/></td></tr>

	<tr><td>Last name</td><td><input type="text" id="last_name" class="form-control" name="last_name" value="<?php echo $last_name ;?>"/></td></tr>

	<tr><td>Contact Number</td><td><input type="text" id="phno" class="form-control" name="phno" value="<?php echo $phno ;?>"/></td></tr>

	<tr><td>Is Active</td><td><input type="text" id="is_active" class="form-control no-drop" name="is_active" value="<?php echo $is_active ;?>" readonly="readonly" /></td></tr>

	<tr><td>Class</td><td><input type="text" id="class_id" class="form-control no-drop	" name="class_id" value="<?php echo $class_id ;?>" readonly="readonly" /></td></tr>

	</table>

<input type="button" style="margin-top: 2%;" onclick="updatestudent()" class="btn btn-success" name="register" value="UPDATE">
</div>
</body>
</html>
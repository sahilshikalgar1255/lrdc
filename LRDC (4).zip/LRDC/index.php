<?php

session_start();


//$user = $_SESSION['fid'];
//setcookie("fid",$_GET['fid']);

if(isset($_SESSION['username']))
{
  $user = $_SESSION['fid'];
  header("location:dashboards/".$user."_Dashboard.php");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>LRDC</title>
    <meta charset="utf-8">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <!-- Custom Fonts -->
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   <script>
	function display()
	{
		
		if(!getCookie("view-mode"))
		{
			return false;
		}
		else
		{
			var viewmode = getCookie("view-mode");
			if(viewmode == "desktop"){
				viewport.setAttribute('content','width=1024');
			}
			else if(viewmode == "mobile")
			{
				viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
			}
			return true;
		}
	}
  </script>
    <style>
            .jumbotron{
     
        background-size:cover;
      
        background:linear-gradient(rgba(70,140,70,0.7),rgba(17,76,60,1.0));
     
        
      
    }
        .carousel-inner img {
      width: 100%;
      height:350px;
        margin-top: 1%;
      }
      
  h3,h2,h4{

    letter-spacing: 4px;
    word-spacing: 5px;
    line-height: 50px;
  }
	
p{
	font-weight:bold;
	letter-spacing:2px;
	word-spacing:3px;
	font-size:20px;
}

#logo{

margin-left:10px;
float:left;
border-radius: 50%;
}

body{
	font-family:Times New Roman;
	
}
</style>

</head>
<body onload="display()">

  <nav class="navbar navbar-expand " style="background-color: black;">

    <a href="index.php" class="navbar-brand font-weight-bold text-light" style="letter-spacing: 3px;">
         LRDC
    </a>
   

  
    <ul class="navbar-nav ml-auto mr-5 px-5">
        <li class="navbar-brand "><a href="index.php" class="nav-link text-light"><i class="fa fa-home fa-fw"></i>Home</a></li>
        

        <li class="nav-item dropdown navbar-brand ">
            <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-sign-in fa-fw"></i>
                Login
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="login/login.php?fid=admin" id="admin">Admin</a>
                <a class="dropdown-item" href="login/login.php?fid=faculty" id="faculty">Faculty</a>
                <a class="dropdown-item" href="login/login.php?fid=student" id="student">Student</a>
            </div>
        </li>
    </ul>
    
</nav>

<div class="jumbotron text-center"  style="margin-bottom:-2%;color:white;font-family:Times New Roman;">
  <img id="logo" src="images/PCCOE_LOGO.jpg" width="160" height="130" />
  
<center>
  <h1>Pimpri Chinchwad College of Engineering, Pune.</h1>
  <h3>MCA DEPARTMENT</h3>
  <h3 class="text-capitalize">learning resource development center</h3>
  
</center>



</div>

<br>

<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
     
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/jumbo.jpeg" alt="Los Angeles" width="1100" height="300">
    </div>
    <div class="carousel-item">
      <img src="images/p4.jpg" alt="Chicago" width="1100" height="300">
    </div>
    <div class="carousel-item">
      <img src="images/p6.jpg" alt="New York" width="1100" height="300">
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<br>
<div class="container" style="margin-top:60px;margin-bottom:80px;font-family: Times New Roman;font-weight: bold;">
                <h2 class="text-center text-danger font-weight-bold text-uppercase">our vision</h2>
                 <hr style="width:50%;">
                <div class="text-justify" style="font-size: 20px;border-radius:10px;">
                    <h1 class="text-center text-primary">" To provide a platform for sharing learning material "</h1>
                    <h1 class="text-center text-primary">" To provide a discussion forum to enhance the learning "</h1>
            </div>
        </div>



<br>
    <div class="container" style="margin-top:60px;margin-bottom:80px;font-family: Times New Roman;font-weight: bold;">
                <h2 class="text-center text-danger font-weight-bold text-uppercase">what you will get here?</h2>
                 <hr style="width:50%;">
                 <div class="container">
        <div class="row main">
        <div class=" col-xm-6 mr-auto">
            <div class="card" style="width:400px;height:500px;">
                <img src="images/repo.png" class="card-img-top" style="width:100%;height:250px;">
                <div class="card-body">
                    <h4 class="card-title text-primary font-weight-bold">Repository</h4>
                   
                    <p class="card-text text-danger">Now store all your data under one roof.</p>
                
            
                     <p class="card-text text-danger">Easily access important files.</p>
                
                     <p class="card-text text-danger">Easily share your files.</p>
                 
                   
                </div>
            </div>
        </div>
        <div class=" col-xm-6 ml-auto">
            <div class="card" style="width:400px;height:500px;">
                <img src="images/forum.jpeg" class="card-img-top" style="width:100%;height:250px;">
                <div class="card-body">
                    <h4 class="card-title text-primary font-weight-bold">Discussion Forum</h4>
                  
                    <p class="card-text text-danger">Share your valuable doubts</p>
              
                     <p class="card-text text-danger">Learn new things</p>
               
                     <p class="card-text text-danger">Share new things</p>
                
                    
                </div>
            </div>
        </div>

 </div>
</div>
</div>


<div class="container" style="margin-top:60px;margin-bottom:80px;font-family: Times New Roman;font-weight: bold;">
                <h2 class="text-center text-danger font-weight-bold text-uppercase">About Institute</h2>
                <hr style="width:50%;">
                <div class="text-justify text-primary" style="font-size: 20px;">
                
                <p> Pimpri Chinchwad Education Trust (PCET) was established by Late Shri. Shankarrao B. Patil in the year 1990 ,</p>
                <p>with a vision to provide value added educational platform to society in multiple dimensions right from Nursery to </p>
                <p>Doctoral programs in all professional streams enabling all our students to achieve Freedom through Education.</p>


            </div>
        </div>


<br>
<br>




          
       <div class="jumbotron text-center"  style="margin-bottom:0px;color:white;font-family:Times New Roman;height:10px;">
          
                    
        <footer class="text-center font-weight-bold" style="letter-spacing: 4px;word-spacing: 10px;">&copy;2019 Pimpri Chinchwad College of Engineering Pune</footer>      
         
    </div>
  



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <!-- Script to Activate the Carousel -->
    <script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>
    
</body>
</html>


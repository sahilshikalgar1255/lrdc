

<!DOCTYPE html>
<html>
<head>
    <title>LRDC</title>
    <meta charset="utf-8">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
-->
    <!-- Custom Fonts -->
<!--    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
   --><script>
	function display()
	{
		
		if(!getCookie("view-mode"))
		{
			return false;
		}
		else
		{
			var viewmode = getCookie("view-mode");
			if(viewmode == "desktop"){
				viewport.setAttribute('content','width=1024');
			}
			else if(viewmode == "mobile")
			{
				viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
			}
			return true;
		}
	}
  </script>
</head>
<body onload="display()">

    <nav class="navbar navbar-expand " style="margin-top:0px;background-color: black;position: sticky;">

    <a href="../index.php" class="navbar-brand font-weight-bold text-light" style="letter-spacing: 3px;">
        <img src="../images/PCCOE_LOGO.jpg" height="50" width="60" alt="" style="border-radius:50%;"> LRDC
    </a>
   

  
    <ul class="navbar-nav ml-auto mr-5 px-5">
        <li class="navbar-brand "><a href="../index.php" class="nav-link text-light"><i class="fa fa-home fa-fw"></i>Home</a></li>
         

        
    </ul>
    
</nav>


<?php

session_start();
$_SESSION['fid'] = $_GET['fid'];
$user = $_SESSION['fid'];


//$user = $_SESSION['fid'];
//setcookie("fid",$_GET['fid']);

if(isset($_SESSION['username']))
{
	header("location:../dashboards/".$user."_Dashboard.php");
}


   
   


?>

    <title>Login</title>
    <meta charset="utf-8">

    <!--<link rel="stylesheet" href="css/bootstrap.css">
    --><style>
        .form-container {
            position: absolute;
            top: 15vh;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px #000;
        }
    </style>



    <h2 class="text-danger font-weight-bold text-center text-uppercase" style="margin-top:7%;letter-spacing: 3px;"><i class="fa fa-sign-in fa-fw"></i><?php
        echo $user;?>

    LOGIN</h2>

<div class="container  text-danger font-weight-bold" style="width:40%;margin-top:2%;padding:2%;border-radius: 10px;background-color:black">


    <form method="post" action="validate.php" class="form-group">
        <label>
            Username
        </label>
        <input type="text" placeholder="Enter Username" name="username" class="form-control" required="">
        <br>
        <label>
            Password
        </label>
        <input type="password" name="password" placeholder="Enter Password" class="form-control" required="">
        <br>
        <input type="submit" class="btn btn-success" style="width:100%;letter-spacing: 3px;" name="submit" value="Login">
        
        <br><br>
        <p><a style="color:white;outline: none;text-decoration: none;" href="forgot.php">forgot password?</a></p>

    </form>



</div>
<br>
<br>


 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>


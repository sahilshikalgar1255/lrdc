<?php
session_start();
require_once("../database/db.php");
if(isset($_POST['submit']))
{
	$username = isset($_POST['username']) ? $_POST['username'] : 0;
	$password = isset($_POST['password']) ? $_POST['password'] : 0;
	
	//setcookie("username",$username);
	//$_SESSION['username'] = $username;
    $table=$_SESSION['fid'];


	$q = "select username,password from $table where username='$username'";

	$res = mysqli_query($con,$q);
	
	  if($rowcount=mysqli_num_rows($res))
	   {
		$_SESSION['username'] = $username;
		header("location:../dashboards/".$table."_Dashboard.php");
	  }
	  else{
		echo"login failed";
		header("location:login.php?fid=".$table);
	}

}

else
{
	  $table=$_SESSION['fid'];

	header("location:login.php");
}

?>

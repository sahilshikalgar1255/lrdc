<?php

if(!isset($_SESSION['username']))
{
	header("location:http://localhost/LRDC/");
}

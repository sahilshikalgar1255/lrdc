<?php
session_start();
  require("session.php");

?>

 <meta charset="utf-8">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">


    
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<script>
	var viewmode = getCookie("view-mode");
	if(viewmode == "desktop"){
		viewport.setAttribute('content','width=1024');
	}else if(viewmode == "mobile"){
		viewport.setAttribute('content','width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no');
	}
  </script>
    <style>
            .jumbotron{
        background-image:url("images/jumbo.jpeg");
        background-size:cover;
        background-repeat:no-repeat;
        background:linear-gradient(rgba(70,140,70,0.7),rgba(17,76,60,1.0));
        color:black;
    }
        .carousel-inner img {
      width: 100%;
      height:350px;
    
  }
</style>

<nav class="navbar navbar-expand " style="margin-top:0px;background-color: black;position: sticky;">

    <a href="../index.php" class="navbar-brand font-weight-bold text-light" style="letter-spacing: 3px;">
        <img src="../images/PCCOE_LOGO.jpg" height="50" width="60" alt="" style="border-radius:50%;"> LRDC
    </a>
   
<?php
      
     $table=$_SESSION['fid'];
     ?>
  
    <ul class="navbar-nav ml-auto mr-5 px-5">
        <li class="navbar-brand "><a href="<?php echo $table; ?>_Dashboard.php" class="nav-link text-light"><i class="fa fa-home fa-fw"></i>Home</a></li>
         <li class="navbar-brand "><a href="../login/logout.php" class="nav-link text-light"><i class="fa fa-sign-out fa-fw"></i>Logout</a></li>
        

        
    </ul>
    
</nav>






 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
